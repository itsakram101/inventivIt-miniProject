package com.example.inventivit_miniproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventivItMiniProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(InventivItMiniProjectApplication.class, args);
    }

}
