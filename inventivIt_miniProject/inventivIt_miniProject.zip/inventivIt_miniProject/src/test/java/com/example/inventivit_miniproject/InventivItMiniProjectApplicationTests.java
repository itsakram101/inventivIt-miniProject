package com.example.inventivit_miniproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventivItMiniProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
